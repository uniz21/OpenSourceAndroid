package com.example.library;

public class MyClass {
}
